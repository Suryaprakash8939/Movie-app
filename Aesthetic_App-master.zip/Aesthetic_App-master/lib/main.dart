import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:uuid/uuid.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Aesthetic App',
      debugShowCheckedModeBanner: false,
      home: MainPage()
    );
  }
}

class MainPage extends StatefulWidget {
  @override
  _MainPageState createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  List movies;

  @override
  void initState() {
    getMovies();
    super.initState();
  }

  void getMovies() async {
    setState(() {movies = null;});
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      if(prefs.containsKey('Movies'))
        movies = json.decode(prefs.getString('Movies'));
      else
        movies = [];
    });
  }

  Future addMovie(BuildContext context) async {
    TextEditingController nameController = new TextEditingController();
    TextEditingController directorController = new TextEditingController();
    final _form = GlobalKey<FormState>();

    return showDialog(
      context: context,
      builder: (ctx){
        return AlertDialog(
          title: Text('Add Movie'),
          content: Container(
            height: 170,
            width: 300,
            child: Form(
              key: _form,
              child: ListView(children: [
                TextFormField(
                  decoration: InputDecoration(
                    labelText: 'Movie Name', alignLabelWithHint: true),
                  controller: nameController,
                  textInputAction: TextInputAction.next,
                  validator: (value) {
                    if (value.isEmpty) return 'Please Enter Name';
                    else return null;
                  }
                ),
                TextFormField(
                  decoration: InputDecoration(
                    labelText: 'Director', alignLabelWithHint: true),
                  controller: directorController,
                  textInputAction: TextInputAction.done,
                  validator: (value) {
                    if (value.isEmpty) return 'Please Enter Director';
                    else return null;
                  }
                )
              ])
            )
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Close', style: TextStyle(color: Colors.red)),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: Text('Submit', style: TextStyle(color: Theme.of(context).primaryColor)),
              onPressed: () async {
                final isValid = _form.currentState.validate();
                if(isValid){
                  final prefs = await SharedPreferences.getInstance();
                  setState(() {
                    movies.add({
                      'Id': Uuid().v1(),
                      'Name': nameController.text,
                      'Director': directorController.text
                    });                
                  });
                  prefs.setString('Movies', json.encode(movies));
                  Navigator.of(context).pop();
                }
              }
            )
          ]
        );
      }
    );
  }

  Future editMovie(BuildContext context, Map movie) async {
    TextEditingController nameController = new TextEditingController();
    nameController.text = movie['Name'];
    TextEditingController directorController = new TextEditingController();
    directorController.text = movie['Director'];
    final _form = GlobalKey<FormState>();

    return showDialog(
      context: context,
      builder: (ctx){
        return AlertDialog(
          title: Text('Add Movie'),
          content: Container(
            height: 170,
            width: 300,
            child: Form(
              key: _form,
              child: ListView(children: [
                TextFormField(
                  decoration: InputDecoration(
                    labelText: 'Movie Name', alignLabelWithHint: true),
                  controller: nameController,
                  textInputAction: TextInputAction.next,
                  validator: (value) {
                    if (value.isEmpty) return 'Please Enter Name';
                    else return null;
                  }
                ),
                TextFormField(
                  decoration: InputDecoration(
                    labelText: 'Director', alignLabelWithHint: true),
                  controller: directorController,
                  textInputAction: TextInputAction.done,
                  validator: (value) {
                    if (value.isEmpty) return 'Please Enter Director';
                    else return null;
                  }
                )
              ])
            )
          ),
          actions: <Widget>[
            TextButton(
              child: Text('Close', style: TextStyle(color: Colors.red)),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: Text('Submit', style: TextStyle(color: Theme.of(context).primaryColor)),
              onPressed: () async {
                final isValid = _form.currentState.validate();
                if(isValid){
                  final prefs = await SharedPreferences.getInstance();
                  setState(() {
                    movies = movies.map((m){
                      if(m['Id'] == movie['Id'])
                        return {
                          'Id': movie['Id'],
                          'Name': nameController.text,
                          'Director': directorController.text
                        };
                      else
                        return m;
                    }).toList();
                  });
                  prefs.setString('Movies', json.encode(movies));
                  Navigator.of(context).pop();
                }
              }
            )
          ]
        );
      }
    );
  }

  void deleteMovie(String id) async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      movies.removeWhere((m) => m['Id'] == id);
    });
    prefs.setString('Movies', json.encode(movies));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Aesthetic App'),
        actions: [
          IconButton(
            icon: Icon(Icons.add),
            onPressed: (){addMovie(context);},  
          )
        ],
      ),
      body: movies == null
      ? Center(child: CircularProgressIndicator()) 
      : Container(
        padding: EdgeInsets.all(10),
        child: ListView(
          children: [
            SizedBox(height: 10),
            ...movies.map((m){
              return Card(
                elevation: 3,
                child: ListTile(
                  title: Text(m['Name']),
                  subtitle: Text(m['Director']),
                  trailing: Container(
                    width: 100,
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.end,
                      children: [
                        IconButton(
                          icon: Icon(Icons.edit),
                          color: Colors.blue,
                          onPressed: () => editMovie(context, m)
                        ),
                        IconButton(
                          icon: Icon(Icons.delete),
                          color: Colors.red,
                          onPressed: () => deleteMovie(m['Id'])
                        )
                      ]
                    ),
                  )
                )
              );
            })
          ]
        )
      )
    );
  }
}